import axios from "axios";
import { Button } from "bootstrap";
import React from "react";
import { useSelector } from "react-redux";

const GetProfile = () => {
  const { data } = useSelector((state) => state.token);

  return (
    <div>
      <div className="container">
        <div className="row d-flex my-5" style={{ justifyContent: "center" }}>
          <div className="col-12 col-sm-6 col-lg-3">
            <div
              className="single_advisor_profile wow fadeInUp"
              data-wow-delay="0.2s"
            >
              <div className="advisor_thumb">
                <img
                  src={data.user.image}
                  alt=""
                  style={{width:"9rem",height:"9rem"}}
                />

                <div className="social-info">
                  <a>
                    <i className="fa fa-facebook"></i>
                  </a>
                  <a>
                    <i className="fa fa-twitter"></i>
                  </a>
                  <a>
                    <i className="fa fa-linkedin"></i>
                  </a>
                </div>
              </div>

              <div className="single_advisor_details_info">
                <h6 className="my-2" style={{fontSize:"2rem"}}>{data.user.username}</h6>
                <h4>Email:<h3>{data.user.email}</h3></h4>
                <h4>Mobile:<h3>{data.user.mobile}</h3></h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetProfile;
