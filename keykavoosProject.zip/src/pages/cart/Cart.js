import Button from "react-bootstrap/esm/Button";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { cart, getPayment, getproduct, getTotal } from "../../Redux/action";
import Container from "react-bootstrap/esm/Container";
import Row from "react-bootstrap/esm/Row";
import Col from "react-bootstrap/esm/Col";
import { Link } from "react-router-dom";

const Cart = () => {
  const { data, loading, error } = useSelector((state) => state.payment);
  const total = useSelector((state) => state.total);
  const cart = useSelector((state) => state.cart);
  const count = useSelector((state) => state.count);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getTotal(data));
  }, []);

  console.log(data);
  console.log(count);
  console.log(total.data);

  return (
    <div>
      <Container>
        <Row>
          {data.map((item) => {
            return (
              <div className=" cartLayer cart-border">
                <Col xs="8">
                  <div className="cartLayer">
                    <img src={item.image} className="image mx-3" />
                    <div className="mx-3">
                      <h3>{item.name}</h3>
                      <h4>{item.price}$</h4>
                      <h5>{item.rating}⭐</h5>
                    </div>
                  </div>
                </Col>
                <Col xs="4">
                  <div >
                    <Button>
                      <div style={{display:"flex"}} >
                      <Button onClick={()=>dispatch({type:"reduce",payload:cart-1})}>
                        -
                      </Button>
                      <h3>{item.counts}</h3>
                      <Button onClick={()=>dispatch({type:"add",payload:cart+1})}>
                        +
                      </Button>
                      </div>
                    </Button>
                    <Button variant="dark">
                      <h5>
                        Price :<h6>{item.totalCount}$</h6>
                      </h5>{" "}
                    </Button>
                  </div>
                </Col>
              </div>
            );
          })}
        </Row>
      </Container>

      <Container>
        <div className="footer">  
          <Button size="lg">Clear Cart items</Button>
          <Button size="lg">
            Total Price :{" "}
            {total.data.reduce((sum, item, index) => {
              return (sum += item);
            }, 0)}
            $
          </Button>
          <Button size="lg" as={Link} to="/address" >Continue</Button>
        </div>
      </Container>
    </div>
  );
};

export default Cart;
