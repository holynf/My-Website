import React, { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Cart, getCart, getPayment, getproduct } from "../../Redux/action";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import Container from "react-bootstrap/esm/Container";
import Row from "react-bootstrap/esm/Row";
import Col from "react-bootstrap/esm/Col";

const Product = () => {
  const dispatch = useDispatch();
  const { data, loading, error } = useSelector((state) => state.product);
  const state = useSelector((state) => state.cart);
  const count = useSelector((state) => state.count);

  const { productId } = useParams();

  data.counts = count
  data.totalCount = count*data.price
  
  useEffect(() => {
    dispatch(getproduct(productId));
    dispatch({type:"coClear"})
  }, []);

  return (
    <div className="d-flex" style={{ width: "100%", justifyContent: "center" }}>
      <div xs="6" className="mx-2">
        <img src={data.image} className="w-50 h-50" />
      </div>
      <div xs="6">
        <h2>{data.name}</h2>
        Color:<h3>{data.color}</h3>
        Price:<h3>{data.price}$</h3>
        Count:
        <h3>
          {data.countInStock !== 0 ? data.countInStock : "Item is Solded Out"}
        </h3>
        Rating:<h3>{data.rating}⭐</h3>
        {data.countInStock === 0 ? (
          <Button disabled>Add To Cart!</Button>
        ) : (
          <div>
            <Button>
              {count !==0 ? <Button onClick={()=>dispatch({type:"coReduce"})}>-</Button> 
              : <Button onClick={()=>dispatch({type:"coReduce"})} disabled>-</Button>}
              <span>{count}</span>
              {data.countInStock > count ? <Button onClick={()=>dispatch({type:"coAdd"})}>+</Button> : 
              <Button onClick={()=>dispatch({type:"coAdd"})} disabled>+</Button>}
            </Button>
            <Button
              onClick={() => {dispatch({ type: "add", payload: count + state })
              dispatch(getPayment(data))
            }}
            >
              Add To Cart!
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Product;
